import unittest

from calc import add, subtract


class TestCalc(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(10, 5), 15)

        # since x.x.x version add() function can handle only positive numbers,
        # so we expect to get an exception
        with self.assertRaises(ValueError):
            add(-1, 1)

        with self.assertRaises(ValueError):
            add(-1, -1)

        with self.assertRaises(ValueError):
            add(1, -1)

    def test_subtract(self):
        self.assertEqual(subtract(10, 5), 5)

        # since x.x.x version subtract() function can handle only positive numbers,
        # so we expect to get an exception
        with self.assertRaises(ValueError):
            subtract(-1, 1)

        with self.assertRaises(ValueError):
            subtract(-1, -1)

        with self.assertRaises(ValueError):
            subtract(1, -1)