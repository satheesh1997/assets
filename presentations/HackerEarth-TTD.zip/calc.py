def add(x, y):
    if x < 0 or y < 0:
        raise ValueError('Only positive numbers are allowed')

    return x + y


def subtract(x, y):
    if x < 0 or y < 0:
        raise ValueError('Only positive numbers are allowed')

    return x - y
